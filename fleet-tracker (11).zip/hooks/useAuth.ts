
import { useState, useEffect } from 'react';
import { auth, onAuthStateChanged, getUserData, FirebaseUser } from '../services/firebase';
import { UserData } from '../types';

export const useAuth = () => {
  const [authUser, setAuthUser] = useState<FirebaseUser | null>(null);
  const [userData, setUserData] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setLoading(true);
      if (user) {
        setAuthUser(user);
        const data = await getUserData(user.uid);
        setUserData(data);
      } else {
        setAuthUser(null);
        setUserData(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return { authUser, userData, loading };
};
