
# Live Fleet Tracker

Una aplicación web para rastrear la ubicación y el estado en tiempo real de las unidades de una flota. Incluye un panel de administración para monitorear a todos los usuarios y un panel de usuario para que los conductores individuales informen su estado y ubicación.

## Características

### Panel de Administrador
- **Vista de Mapa General:** Visualiza a todos los usuarios activos en un mapa interactivo.
- **Lista de Usuarios Conectados:** Muestra una lista en tiempo real de los usuarios en línea y su estado actual (Activo, En Pausa).
- **Detalles del Usuario:** Al seleccionar un usuario, se muestra información detallada, incluyendo:
    - Tiempo de actividad en las últimas 24 horas.
    - Número de pausas.
    - Registro de actividad detallado (inicios de sesión, pausas, etc.).
- **Mensajería en Tiempo Real:** Envía mensajes predefinidos a usuarios específicos.
- **Generación de Reportes:** Crea y descarga un informe en PDF con las estadísticas del usuario seleccionado.
- **Control de Capas del Mapa:** Cambia entre vistas de mapa vehicular, nocturna y satelital.

### Panel de Usuario
- **Seguimiento GPS en Tiempo Real:** Muestra la ubicación actual del usuario en el mapa.
- **Gestión de Estado:** Permite al usuario cambiar su estado entre "Activo" y "En Pausa". El seguimiento se detiene durante la pausa.
- **Notificaciones y Mensajes:** Recibe mensajes en tiempo real del administrador.
- **Controles del Mapa:** Centra el mapa en la ubicación actual del usuario y cambia entre diferentes estilos de mapa.
- **Cierre de Sesión Seguro:** Permite al usuario cerrar sesión, actualizando su estado a "offline".

## Estructura del Proyecto

El proyecto está organizado siguiendo una estructura de carpetas estándar para aplicaciones React, con el fin de promover la escalabilidad y la mantenibilidad.

```
live-fleet-tracker/
├── public/
│   └── vite.svg
├── src/
│   ├── components/
│   │   ├── Login.tsx
│   │   ├── MapComponent.tsx
│   │   ├── Notification.tsx
│   │   └── Spinner.tsx
│   ├── constants/
│   │   └── index.ts
│   ├── hooks/
│   │   ├── useAuth.ts
│   │   └── useGeolocation.ts
│   ├── screens/
│   │   ├── AdminDashboard.tsx
│   │   ├── LoadingScreen.tsx
│   │   └── UserDashboard.tsx
│   ├── services/
│   │   └── firebase.ts
│   ├── types/
│   │   └── index.ts
│   ├── utils/
│   │   └── pdf.ts
│   ├── App.tsx
│   ├── index.css
│   └── index.tsx
├── .env.example
├── .gitignore
├── index.html
├── package.json
├── postcss.config.js
├── tailwind.config.js
└── vite.config.ts
```

## Tecnologías Utilizadas
- **Frontend:** React 19, Vite, TypeScript
- **Estilos:** Tailwind CSS
- **Mapas:** Leaflet, OpenStreetMap
- **Backend y Base de Datos:** Firebase (Authentication, Firestore, Realtime Database)
- **Generación de PDF:** jsPDF, html2canvas

## Cómo Empezar

Sigue estas instrucciones para configurar y ejecutar el proyecto en tu máquina local.

### Prerrequisitos
- Node.js (versión 18 o superior)
- `npm` o `yarn` como gestor de paquetes

### 1. Instalación
Clona el repositorio e instala las dependencias:

```bash
git clone <URL_DEL_REPOSITORIO>
cd live-fleet-tracker
npm install
```

### 2. Configuración de Firebase

**a. Crea un proyecto en Firebase:**
   - Ve a la [Consola de Firebase](https://console.firebase.google.com/).
   - Crea un nuevo proyecto.
   - Registra una nueva aplicación web y anota las credenciales de configuración.

**b. Habilita los servicios necesarios:**
   - **Authentication:** Ve a la sección `Authentication`, haz clic en `Empezar` y habilita el proveedor **Correo electrónico/Contraseña**.
   - **Firestore Database:** Ve a `Firestore`, crea una base de datos en modo de producción.
   - **Realtime Database:** Ve a `Realtime Database`, crea una base de datos en modo de producción.

**c. Configura la base de datos de Firestore:**
   - Crea una colección raíz llamada `users`.
   - Añade documentos donde el ID del documento sea el `UID` del usuario de Firebase Authentication.
   - Cada documento de usuario debe tener los siguientes campos:
     - `name` (string)
     - `email` (string)
     - `role` (string: `'admin'` o `'user'`)
     - `createdAt` (timestamp)

### 3. Variables de Entorno

Crea un archivo `.env` en la raíz del proyecto. Puedes copiar el contenido de `.env.example` y llenarlo con tus propias credenciales de Firebase.

```bash
cp .env.example .env
```

Abre el archivo `.env` y añade tus claves:
```env
VITE_FIREBASE_API_KEY="TU_API_KEY"
VITE_FIREBASE_AUTH_DOMAIN="TU_AUTH_DOMAIN"
VITE_FIREBASE_DATABASE_URL="TU_DATABASE_URL"
VITE_FIREBASE_PROJECT_ID="TU_PROJECT_ID"
VITE_FIREBASE_STORAGE_BUCKET="TU_STORAGE_BUCKET"
VITE_FIREBASE_MESSAGING_SENDER_ID="TU_MESSAGING_SENDER_ID"
VITE_FIREBASE_APP_ID="TU_APP_ID"
```

### 4. Ejecutar la Aplicación

Una vez que hayas instalado las dependencias y configurado las variables de entorno, puedes iniciar el servidor de desarrollo:

```bash
npm run dev
```

Abre tu navegador y ve a `http://localhost:5173` (o el puerto que Vite indique).
