
import React, { useEffect, useRef } from 'react';
import { UserStatus, Location } from '../types';
import L from 'leaflet';

// Fix for default icon issue with webpack
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});


const createColoredIcon = (color: string) => {
    const markerHtmlStyles = `
      background-color: ${color};
      width: 2rem;
      height: 2rem;
      display: block;
      left: -1rem;
      top: -1rem;
      position: relative;
      border-radius: 2rem 2rem 0;
      transform: rotate(45deg);
      border: 1px solid #FFFFFF;`;
  
    return L.divIcon({
      className: "my-custom-pin",
      iconAnchor: [0, 24],
      popupAnchor: [0, -36],
      html: `<span style="${markerHtmlStyles}" />`
    })
};


interface MapComponentProps {
  center: Location;
  zoom?: number;
  users: UserStatus[];
  tileUrl: string;
  tileAttribution: string;
  currentUserUid: string;
}

const MapComponent: React.FC<MapComponentProps> = ({ center, zoom = 16, users, tileUrl, tileAttribution, currentUserUid }) => {
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<{ [key: string]: L.Marker }>({});

  useEffect(() => {
    if (!mapRef.current) {
        mapRef.current = L.map('map-container').setView([center.lat, center.lng], zoom);
    } else {
        mapRef.current.setView([center.lat, center.lng], mapRef.current.getZoom());
    }
    
    const tileLayer = L.tileLayer(tileUrl, { attribution: tileAttribution });
    
    // Check if a tile layer already exists and replace it, otherwise add it
    let foundLayer = false;
    mapRef.current.eachLayer(layer => {
        if (layer instanceof L.TileLayer) {
            mapRef.current?.removeLayer(layer);
        }
    });
    mapRef.current.addLayer(tileLayer);

  }, [center, zoom, tileUrl, tileAttribution]);

  useEffect(() => {
      const currentMarkerIds = users.map(u => u.uid);

      // Remove markers for users who are no longer present
      Object.keys(markersRef.current).forEach(markerId => {
          if (!currentMarkerIds.includes(markerId)) {
              markersRef.current[markerId].remove();
              delete markersRef.current[markerId];
          }
      });
      
      // Add/update markers for current users
      users.forEach(user => {
        if (user.location && user.isOnline) {
          const popupContent = `
            <div class="font-sans">
              <h3 class="font-bold text-lg">${user.name}</h3>
              <p class="text-gray-600">${user.uid === currentUserUid ? 'Your Location' : 'User'}</p>
              <p>Status: <span class="font-semibold capitalize">${user.state}</span></p>
              <p>Lat: ${user.location.lat.toFixed(5)}, Lng: ${user.location.lng.toFixed(5)}</p>
            </div>
          `;
          
          if (markersRef.current[user.uid]) {
            markersRef.current[user.uid].setLatLng([user.location.lat, user.location.lng]);
            markersRef.current[user.uid].getPopup()?.setContent(popupContent);
          } else {
            const marker = L.marker([user.location.lat, user.location.lng], {
              icon: createColoredIcon(user.color || '#3b82f6')
            })
              .addTo(mapRef.current!)
              .bindPopup(popupContent);
            markersRef.current[user.uid] = marker;
          }
        }
      });
  }, [users, currentUserUid]);


  return <div id="map-container" className="h-full w-full z-0"></div>;
};

export default MapComponent;
