
import React, { useState, useEffect } from 'react';

interface NotificationProps {
  message: string;
  onDismiss: () => void;
}

const Notification: React.FC<NotificationProps> = ({ message, onDismiss }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss();
    }, 5000); // Auto-dismiss after 5 seconds

    return () => clearTimeout(timer);
  }, [onDismiss]);

  return (
    <div className="fixed top-5 right-5 bg-gray-700 text-white py-2 px-4 rounded-lg shadow-lg animate-fade-in-down">
      <p>{message}</p>
    </div>
  );
};

export default Notification;
