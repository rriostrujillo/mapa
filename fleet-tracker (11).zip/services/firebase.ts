import * as firebaseApp from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, signOut as firebaseSignOut, onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { getFirestore, doc, getDoc, collection, addDoc, serverTimestamp, query, where, getDocs, orderBy, limit, Timestamp } from 'firebase/firestore';
import { getDatabase, ref, set, onValue, onDisconnect, serverTimestamp as rtdbServerTimestamp, push, query as rtdbQuery } from 'firebase/database';
import { UserData, Role, UserStatus, UserState, ActivityLog, Location, AppMessage } from '../types';

// IMPORTANT: Replace with your actual Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDfVR-3Emt4h8RY8K5nGYu_hqWFLPAL00", // Placeholder from image
  authDomain: "mapa-en-vivo-3b9b1.firebaseapp.com",
  databaseURL: "mapa-en-vivo-3b9b1-default-rtdb.firebaseio.com",
  projectId: "mapa-en-vivo-3b9b1",
  storageBucket: "mapa-en-vivo-3b9b1.firebasestorage.app",
  messagingSenderId: "897356095340",
  appId: "1:897356095340:web:5f9740162fd7dfdd29dd49"
};

const app = firebaseApp.initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const rtdb = getDatabase(app);

// --- Authentication ---
export const signInUser = (email: string, password: string) => signInWithEmailAndPassword(auth, email, password);
export const signOutUser = async () => {
    if(auth.currentUser){
        await logActivity(auth.currentUser.uid, 'logout');
        await setUserStatus(auth.currentUser.uid, { state: UserState.OFFLINE, location: null });
    }
    await firebaseSignOut(auth);
};
export { onAuthStateChanged };
export type { FirebaseUser };

// --- Firestore ---
export const getUserData = async (uid: string): Promise<UserData | null> => {
  const userDocRef = doc(db, 'users', uid);
  const userDoc = await getDoc(userDocRef);
  if (userDoc.exists()) {
    return { uid, ...userDoc.data() } as UserData;
  }
  return null;
};

export const logActivity = (uid: string, event: ActivityLog['event']) => {
    const activityCollectionRef = collection(db, 'users', uid, 'activity-log');
    return addDoc(activityCollectionRef, {
        event,
        timestamp: serverTimestamp()
    });
};

export const getActivityLogs = async (uid: string): Promise<ActivityLog[]> => {
    const twentyFourHoursAgo = Timestamp.fromMillis(Date.now() - 24 * 60 * 60 * 1000);
    const activityCollectionRef = collection(db, 'users', uid, 'activity-log');
    const q = query(activityCollectionRef, where('timestamp', '>=', twentyFourHoursAgo), orderBy('timestamp', 'desc'), limit(100));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ActivityLog));
}

// --- Realtime Database ---
export const setupPresence = (uid: string, userData: UserData) => {
    const userStatusRef = ref(rtdb, `status/${uid}`);
    const connectionRef = ref(rtdb, '.info/connected');

    onValue(connectionRef, (snap) => {
        if (snap.val() === true) {
            set(userStatusRef, {
                uid: userData.uid,
                name: userData.name,
                isOnline: true,
                state: UserState.ACTIVE,
                lastSeen: rtdbServerTimestamp(),
                color: `#${Math.floor(Math.random()*16777215).toString(16).padStart(6, '0')}` // Random color for map marker
            });

            onDisconnect(userStatusRef).set({
                uid: userData.uid,
                name: userData.name,
                isOnline: false,
                state: UserState.OFFLINE,
                lastSeen: rtdbServerTimestamp(),
                location: null
            });

            logActivity(uid, 'login');
        }
    });
};

export const updateUserLocation = (uid: string, location: Location) => {
    const userStatusRef = ref(rtdb, `status/${uid}/location`);
    set(userStatusRef, location);
    const lastSeenRef = ref(rtdb, `status/${uid}/lastSeen`);
    set(lastSeenRef, rtdbServerTimestamp());
};

export const setUserStatus = (uid: string, status: { state: UserState, location?: Location | null }) => {
    const userStatusRef = ref(rtdb, `status/${uid}`);
    set(userStatusRef, {
        ...status,
        isOnline: status.state !== UserState.OFFLINE,
        lastSeen: rtdbServerTimestamp(),
    });

    if (status.state === UserState.PAUSED) {
        logActivity(uid, 'pause_start');
    } else if (status.state === UserState.ACTIVE) {
        logActivity(uid, 'pause_end');
    }
};

export const listenToAllUsersStatus = (callback: (users: Record<string, UserStatus>) => void) => {
    const statusRef = ref(rtdb, 'status');
    onValue(statusRef, (snap) => {
        if(snap.exists()){
            callback(snap.val());
        } else {
            callback({});
        }
    });
};

export const sendMessageToUser = (uid: string, message: string) => {
    const messagesRef = ref(rtdb, `messages/${uid}`);
    const newMessageRef = push(messagesRef);
    set(newMessageRef, {
        text: message,
        timestamp: rtdbServerTimestamp(),
        read: false
    });
};

export const listenToMessages = (uid: string, callback: (messages: AppMessage[]) => void) => {
    const messagesRef = rtdbQuery(ref(rtdb, `messages/${uid}`));
    onValue(messagesRef, (snap) => {
        if (snap.exists()) {
            const messagesData = snap.val();
            const messagesList: AppMessage[] = Object.keys(messagesData).map(key => ({
                id: key,
                ...messagesData[key]
            }));
            callback(messagesList);
        } else {
            callback([]);
        }
    });
};