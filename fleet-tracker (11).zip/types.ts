import { Timestamp } from 'firebase/firestore';

export enum Role {
  ADMIN = 'admin',
  USER = 'user',
}

export interface UserData {
  uid: string;
  name: string;
  email: string;
  role: Role;
  createdAt: Timestamp;
}

export interface Location {
  lat: number;
  lng: number;
}

export enum UserState {
    ACTIVE = 'active',
    PAUSED = 'paused',
    OFFLINE = 'offline'
}

export interface UserStatus {
  uid: string;
  name: string;
  isOnline: boolean;
  state: UserState;
  location: Location | null;
  lastSeen: number; // using serverTimestamp which resolves to a number
  color: string;
}

export interface ActivityLog {
    id: string;
    event: 'login' | 'logout' | 'pause_start' | 'pause_end';
    timestamp: Timestamp;
}

export interface AppMessage {
    id: string;
    text: string;
    timestamp: number;
    read: boolean;
}