
import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useGeolocation } from '../hooks/useGeolocation';
import { signOutUser, setupPresence, updateUserLocation, setUserStatus, listenToAllUsersStatus, listenToMessages, logActivity } from '../services/firebase';
import { MAP_TILES, MAP_ATTRIBUTION } from '../constants';
import MapComponent from '../components/MapComponent';
import Spinner from '../components/Spinner';
import Notification from '../components/Notification';
import { UserStatus, UserState, Location, AppMessage, UserData } from '../types';

const UserDashboard: React.FC = () => {
    const { authUser, userData } = useAuth();
    const { location: myLocation, error: geoError } = useGeolocation({ enableHighAccuracy: true, timeout: 5000, maximumAge: 0 });
    
    const [allUsers, setAllUsers] = useState<UserStatus[]>([]);
    const [mapCenter, setMapCenter] = useState<Location>({ lat: 16.7532, lng: -93.1156 }); // Default to Tuxtla Gutierrez
    const [userState, setUserState] = useState<UserState>(UserState.ACTIVE);
    const [currentTile, setCurrentTile] = useState<'VEHICULAR' | 'NIGHT' | 'SATELLITE'>('VEHICULAR');
    const [notifications, setNotifications] = useState<string[]>([]);
    const [messages, setMessages] = useState<AppMessage[]>([]);

    useEffect(() => {
        if (userData) {
            setupPresence(userData.uid, userData);
            listenToAllUsersStatus((users) => {
                const userArray = Object.values(users).filter(u => u.isOnline);
                setAllUsers(userArray);
            });
            listenToMessages(userData.uid, (msgs) => {
                setMessages(msgs);
            });
        }
    }, [userData]);

    useEffect(() => {
        if (myLocation && userState === UserState.ACTIVE && authUser) {
            updateUserLocation(authUser.uid, myLocation);
            setMapCenter(myLocation);
        }
    }, [myLocation, userState, authUser]);

    const handlePauseToggle = () => {
        if (!authUser) return;
        const newState = userState === UserState.ACTIVE ? UserState.PAUSED : UserState.ACTIVE;
        setUserState(newState);
        setUserStatus(authUser.uid, { state: newState, location: myLocation });
    };

    const centerMap = () => {
        if (myLocation) {
            setMapCenter(myLocation);
        }
    }
    
    if (!authUser || !userData) {
        return <div className="h-screen w-screen bg-gray-900 flex items-center justify-center"><Spinner /></div>;
    }

    return (
        <div className="relative h-screen w-screen bg-gray-800 text-white flex flex-col">
            <header className="absolute top-0 left-0 right-0 z-10 flex justify-between items-center p-4 bg-gray-900/50 backdrop-blur-sm">
                <div className="flex items-center gap-4">
                    <h1 className="text-xl font-bold">User Dashboard</h1>
                    <span className={`capitalize px-2 py-1 text-xs rounded-full ${userState === UserState.ACTIVE ? 'bg-green-500' : 'bg-yellow-500'}`}>
                        {userState}
                    </span>
                </div>
                <div className="flex items-center gap-2">
                    <button onClick={centerMap} className="px-3 py-2 bg-blue-600 rounded-md hover:bg-blue-700">Center</button>
                    <button onClick={handlePauseToggle} className="px-3 py-2 bg-yellow-500 rounded-md hover:bg-yellow-600">{userState === UserState.ACTIVE ? 'Pause' : 'Resume'}</button>
                    <select onChange={(e) => setCurrentTile(e.target.value as 'VEHICULAR' | 'NIGHT' | 'SATELLITE')} value={currentTile} className="bg-gray-700 border border-gray-600 rounded-md p-2 focus:outline-none">
                        <option value="VEHICULAR">Vehicular</option>
                        <option value="NIGHT">Night</option>
                        <option value="SATELLITE">Satellite</option>
                    </select>
                    <button onClick={signOutUser} className="px-3 py-2 bg-red-600 rounded-md hover:bg-red-700">Logout</button>
                </div>
            </header>
            
            <main className="flex-grow pt-[72px]">
                 <MapComponent 
                    center={mapCenter} 
                    users={allUsers}
                    tileUrl={MAP_TILES[currentTile]}
                    tileAttribution={MAP_ATTRIBUTION[currentTile]}
                    currentUserUid={authUser.uid}
                 />
            </main>

            {messages.length > 0 && (
                <div className="absolute bottom-5 left-5 z-10 bg-gray-800 p-4 rounded-lg shadow-lg max-w-sm">
                    <h3 className="font-bold mb-2">Admin Messages</h3>
                    <div className="max-h-40 overflow-y-auto">
                        {messages.slice().reverse().map(msg => (
                            <div key={msg.id} className={`p-2 rounded-md ${msg.read ? 'bg-gray-700' : 'bg-blue-900/50'}`}>
                                <p>{msg.text}</p>
                                <p className="text-xs text-gray-400 text-right">{new Date(msg.timestamp).toLocaleTimeString()}</p>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

export default UserDashboard;
