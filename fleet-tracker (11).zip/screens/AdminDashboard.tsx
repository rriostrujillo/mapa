import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { signOutUser, setupPresence, listenToAllUsersStatus, getActivityLogs, sendMessageToUser } from '../services/firebase';
import { MAP_TILES, MAP_ATTRIBUTION, PREDEFINED_MESSAGES } from '../constants';
import MapComponent from '../components/MapComponent';
import Spinner from '../components/Spinner';
import { generatePdfFromElement } from '../utils/pdf';
import { UserStatus, Location, ActivityLog } from '../types';
import { Timestamp } from '@firebase/firestore';

const AdminDashboard: React.FC = () => {
    const { authUser, userData } = useAuth();
    
    const [allUsers, setAllUsers] = useState<UserStatus[]>([]);
    const [selectedUser, setSelectedUser] = useState<UserStatus | null>(null);
    const [selectedUserLogs, setSelectedUserLogs] = useState<ActivityLog[]>([]);
    const [mapCenter, setMapCenter] = useState<Location>({ lat: 16.7532, lng: -93.1156 });
    const [currentTile, setCurrentTile] = useState<'VEHICULAR' | 'NIGHT' | 'SATELLITE'>('NIGHT');
    const [loadingLogs, setLoadingLogs] = useState(false);

    useEffect(() => {
        if (userData) {
            setupPresence(userData.uid, userData);
            listenToAllUsersStatus((users) => {
                const userArray = Object.values(users).filter(u => u.isOnline);
                setAllUsers(userArray);
            });
        }
    }, [userData]);

    const handleSelectUser = async (user: UserStatus) => {
        setSelectedUser(user);
        if (user.location) {
            setMapCenter(user.location);
        }
        setLoadingLogs(true);
        const logs = await getActivityLogs(user.uid);
        setSelectedUserLogs(logs);
        setLoadingLogs(false);
    };
    
    const handleSendMessage = (message: string) => {
        if (selectedUser) {
            sendMessageToUser(selectedUser.uid, message);
            alert(`Message sent to ${selectedUser.name}`);
        }
    };

    const handleGenerateReport = () => {
        if (selectedUser) {
            generatePdfFromElement('userDetailPanel', `report-${selectedUser.name}-${new Date().toISOString().split('T')[0]}.pdf`);
        }
    };
    
    if (!authUser || !userData) {
        return <div className="h-screen w-screen bg-gray-900 flex items-center justify-center"><Spinner /></div>;
    }
    
    const calculateStats = () => {
        if (selectedUserLogs.length === 0) return { activeTime: '0h 0m', pauses: 0 };
        let activeTimeMs = 0;
        let pauses = 0;
        let lastLoginTime: Timestamp | null = null;
    
        const sortedLogs = [...selectedUserLogs].sort((a,b) => a.timestamp.toMillis() - b.timestamp.toMillis());

        sortedLogs.forEach(log => {
            if (log.event === 'login') {
                lastLoginTime = log.timestamp;
            } else if (log.event === 'logout' && lastLoginTime) {
                activeTimeMs += log.timestamp.toMillis() - lastLoginTime.toMillis();
                lastLoginTime = null;
            } else if (log.event === 'pause_start') {
                pauses++;
            }
        });
        
        // If still logged in, count time until now
        if (lastLoginTime) {
            activeTimeMs += Date.now() - lastLoginTime.toMillis();
        }
        
        const hours = Math.floor(activeTimeMs / (1000 * 60 * 60));
        const minutes = Math.floor((activeTimeMs % (1000 * 60 * 60)) / (1000 * 60));

        return { activeTime: `${hours}h ${minutes}m`, pauses };
    }

    const stats = selectedUser ? calculateStats() : { activeTime: 'N/A', pauses: 0 };

    return (
        <div className="h-screen w-screen bg-gray-900 text-white flex">
            <aside className="w-1/3 max-w-sm flex flex-col h-full bg-gray-800 p-4 border-r border-gray-700">
                <div className="flex justify-between items-center mb-4">
                    <h1 className="text-xl font-bold">Admin Panel</h1>
                    <button onClick={signOutUser} className="px-3 py-1 bg-red-600 rounded-md hover:bg-red-700 text-sm">Logout</button>
                </div>

                <div className="flex-shrink-0 mb-4">
                    <h2 className="text-lg font-semibold mb-2">Connected Users ({allUsers.length})</h2>
                    <ul className="space-y-2 max-h-48 overflow-y-auto">
                        {allUsers.map(user => (
                            <li key={user.uid} onClick={() => handleSelectUser(user)}
                                className={`flex items-center p-2 rounded-md cursor-pointer ${selectedUser?.uid === user.uid ? 'bg-blue-600' : 'bg-gray-700 hover:bg-gray-600'}`}>
                                <span className="w-3 h-3 rounded-full mr-3" style={{ backgroundColor: user.color }}></span>
                                <span className="flex-grow">{user.name}</span>
                                <span className={`capitalize text-xs px-2 py-0.5 rounded-full ${user.state === 'active' ? 'bg-green-500/50' : 'bg-yellow-500/50'}`}>{user.state}</span>
                            </li>
                        ))}
                    </ul>
                </div>

                <div id="userDetailPanel" className="flex-grow bg-gray-900 rounded-lg p-4 overflow-y-auto">
                    <h2 className="text-lg font-semibold mb-2">User Details</h2>
                    {selectedUser ? (
                        <div className="space-y-3">
                            <h3 className="text-xl font-bold text-blue-400">{selectedUser.name}</h3>
                            <p><span className="font-semibold">Status:</span> <span className="capitalize">{selectedUser.state}</span></p>
                            <p><span className="font-semibold">Active Time (24h):</span> {stats.activeTime}</p>
                            <p><span className="font-semibold">Pauses (24h):</span> {stats.pauses}</p>
                            
                            <div className="space-y-2 pt-2">
                               <h4 className="font-semibold">Send Message:</h4>
                               <div className="flex flex-col gap-2">
                                   {PREDEFINED_MESSAGES.map(msg => (
                                       <button key={msg} onClick={() => handleSendMessage(msg)} className="text-left text-sm w-full p-2 bg-gray-700 hover:bg-gray-600 rounded-md">{msg}</button>
                                   ))}
                               </div>
                            </div>

                             <div className="space-y-2 pt-2">
                               <h4 className="font-semibold">Activity Log (Last 24h):</h4>
                               {loadingLogs ? <Spinner /> : (
                                   <ul className="text-xs space-y-1 max-h-40 overflow-y-auto">
                                       {selectedUserLogs.map(log => (
                                           <li key={log.id} className="flex justify-between p-1 bg-gray-800 rounded">
                                               <span>{log.event}</span>
                                               <span className="text-gray-400">{log.timestamp.toDate().toLocaleString()}</span>
                                           </li>
                                       ))}
                                   </ul>
                               )}
                            </div>

                            <button onClick={handleGenerateReport} className="mt-4 w-full py-2 bg-green-600 hover:bg-green-700 rounded-md">Generate PDF Report</button>
                        </div>
                    ) : <p className="text-gray-400">Select a user to see details.</p>}
                </div>
            </aside>
            <main className="flex-grow relative">
                 <MapComponent 
                    center={mapCenter} 
                    users={allUsers}
                    tileUrl={MAP_TILES[currentTile]}
                    tileAttribution={MAP_ATTRIBUTION[currentTile]}
                    currentUserUid={authUser.uid}
                 />
                 <div className="absolute top-4 right-4 z-10">
                     <select onChange={(e) => setCurrentTile(e.target.value as 'VEHICULAR' | 'NIGHT' | 'SATELLITE')} value={currentTile} className="bg-gray-700 border border-gray-600 rounded-md p-2 focus:outline-none">
                        <option value="VEHICULAR">Vehicular</option>
                        <option value="NIGHT">Night</option>
                        <option value="SATELLITE">Satellite</option>
                    </select>
                 </div>
            </main>
        </div>
    );
};

export default AdminDashboard;