
import React from 'react';
import Spinner from '../components/Spinner';

const LoadingScreen: React.FC = () => {
  return (
    <div className="flex items-center justify-center h-screen bg-gray-900 text-white">
      <div className="text-center">
        <Spinner />
        <p className="mt-4 text-lg">Loading Fleet Tracker...</p>
      </div>
    </div>
  );
};

export default LoadingScreen;
