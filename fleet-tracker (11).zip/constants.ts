
export const PREDEFINED_MESSAGES = [
    'Favor de contactarse a la base',
    'Viaje asignado.',
    'Viaje cancelado.',
    'Regresar a la base.',
    'Descanso concedido.'
];

export const MAP_TILES = {
    VEHICULAR: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    NIGHT: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
    SATELLITE: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
};

export const MAP_ATTRIBUTION = {
    VEHICULAR: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    NIGHT: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
    SATELLITE: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
}
