import * as firebaseApp from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, signOut as firebaseSignOut, onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { getFirestore, doc, getDoc, collection, addDoc, serverTimestamp, query, where, getDocs, orderBy, limit, Timestamp } from 'firebase/firestore';
import { getDatabase, ref, set, onValue, onDisconnect, serverTimestamp as rtdbServerTimestamp, push, query as rtdbQuery, update, Unsubscribe } from 'firebase/database';
import { UserData, UserState, ActivityLog, Location, AppMessage, UserStatus } from '../types';

// Firebase configuration is loaded from environment variables for security and flexibility.
// See the README.md file for instructions on setting up your .env file.
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
};

// Validate that Firebase environment variables are set.
if (!firebaseConfig.apiKey) {
  throw new Error("VITE_FIREBASE_API_KEY is not set. Please check your .env file.");
}

const app = firebaseApp.initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const rtdb = getDatabase(app);

// --- Authentication ---
export const signInUser = (email: string, password: string) => signInWithEmailAndPassword(auth, email, password);

export const signOutUser = async () => {
    if(auth.currentUser){
        const userStatusRef = ref(rtdb, `status/${auth.currentUser.uid}`);
        await update(userStatusRef, {
            isOnline: false,
            state: UserState.OFFLINE,
        });
        await logActivity(auth.currentUser.uid, 'logout');
    }
    await firebaseSignOut(auth);
};
export { onAuthStateChanged };
export type { FirebaseUser };

// --- Firestore ---
export const getUserData = async (uid: string): Promise<UserData | null> => {
  const userDocRef = doc(db, 'users', uid);
  const userDoc = await getDoc(userDocRef);
  if (userDoc.exists()) {
    return { uid, ...userDoc.data() } as UserData;
  }
  return null;
};

export const logActivity = (uid: string, event: ActivityLog['event']) => {
    const activityCollectionRef = collection(db, 'users', uid, 'activity-log');
    return addDoc(activityCollectionRef, {
        event,
        timestamp: serverTimestamp()
    });
};

export const getActivityLogs = async (uid: string): Promise<ActivityLog[]> => {
    const twentyFourHoursAgo = Timestamp.fromMillis(Date.now() - 24 * 60 * 60 * 1000);
    const activityCollectionRef = collection(db, 'users', uid, 'activity-log');
    const q = query(activityCollectionRef, where('timestamp', '>=', twentyFourHoursAgo), orderBy('timestamp', 'desc'), limit(100));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ActivityLog));
}

// --- Realtime Database ---
export const setupPresence = (uid: string, userData: UserData): Unsubscribe => {
    const userStatusRef = ref(rtdb, `status/${uid}`);
    const connectionRef = ref(rtdb, '.info/connected');

    const listener = onValue(connectionRef, (snap) => {
        if (snap.val() !== true) return;

        const statusPayload: Partial<UserStatus> = {
            uid: userData.uid,
            name: userData.name,
            isOnline: true,
            state: UserState.ACTIVE,
            lastSeen: rtdbServerTimestamp(),
            color: `#${Math.floor(Math.random()*16777215).toString(16).padStart(6, '0')}`,
            location: null
        };
        
        set(userStatusRef, statusPayload);

        onDisconnect(userStatusRef).update({
            isOnline: false,
            state: UserState.OFFLINE,
            lastSeen: rtdbServerTimestamp(),
        });

        logActivity(uid, 'login');
    });
    return listener;
};

export const updateUserLocation = (uid: string, location: Location) => {
    const userStatusRef = ref(rtdb, `status/${uid}`);
    update(userStatusRef, {
        location,
        lastSeen: rtdbServerTimestamp()
    });
};

export const updateUserState = (uid: string, state: UserState) => {
    const userStatusRef = ref(rtdb, `status/${uid}`);
    update(userStatusRef, {
        state: state,
        lastSeen: rtdbServerTimestamp()
    });

    const event = state === UserState.PAUSED ? 'pause_start' : 'pause_end';
    if (state !== UserState.OFFLINE) {
        logActivity(uid, event);
    }
};

export const listenToAllUsersStatus = (callback: (users: Record<string, UserStatus>) => void): Unsubscribe => {
    const statusRef = ref(rtdb, 'status');
    return onValue(statusRef, (snap) => {
        callback(snap.exists() ? snap.val() : {});
    });
};

export const sendMessageToUser = (uid: string, message: string) => {
    const messagesRef = ref(rtdb, `messages/${uid}`);
    const newMessageRef = push(messagesRef);
    set(newMessageRef, {
        text: message,
        timestamp: rtdbServerTimestamp(),
        read: false
    });
};

export const listenToMessages = (uid: string, callback: (messages: AppMessage[]) => void): Unsubscribe => {
    const messagesRef = rtdbQuery(ref(rtdb, `messages/${uid}`), orderBy('timestamp'));
    return onValue(messagesRef, (snap) => {
        if (snap.exists()) {
            const messagesData = snap.val();
            const messagesList: AppMessage[] = Object.keys(messagesData).map(key => ({
                id: key,
                ...messagesData[key]
            }));
            callback(messagesList);
        } else {
            callback([]);
        }
    });
};