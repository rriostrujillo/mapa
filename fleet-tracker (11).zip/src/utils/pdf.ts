import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

export const generatePdfFromElement = async (elementId: string, fileName: string = 'report.pdf') => {
  const element = document.getElementById(elementId);
  if (!element) {
    console.error(`Element with id "${elementId}" not found.`);
    return;
  }

  try {
    const canvas = await html2canvas(element, {
      scale: 2, 
      backgroundColor: '#111827', // Match dark theme background from AdminDashboard
      useCORS: true
    });
    const imgData = canvas.toDataURL('image/png');
    
    // Use pt as units and A4 as format for consistency
    const pdf = new jsPDF({
      orientation: 'p',
      unit: 'pt',
      format: 'a4'
    });

    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();
    const canvasAspectRatio = canvas.width / canvas.height;
    
    const imgWidth = pdfWidth - 40; // With some margin
    const imgHeight = imgWidth / canvasAspectRatio;

    let finalHeight = imgHeight;
    if (imgHeight > pdfHeight - 40) {
      finalHeight = pdfHeight - 40;
    }
    
    const x = (pdfWidth - imgWidth) / 2;
    const y = 20;

    pdf.addImage(imgData, 'PNG', x, y, imgWidth, finalHeight);
    pdf.save(fileName);
  } catch (error) {
    console.error("Error generating PDF:", error);
  }
};