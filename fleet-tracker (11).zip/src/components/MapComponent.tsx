import React, { useEffect, useRef } from 'react';
import { UserStatus, Location } from '../types';
import L from 'leaflet';

// Fix for default icon issue with bundlers like Vite/Webpack
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});


const createColoredIcon = (color: string) => {
    const markerHtmlStyles = `
      background-color: ${color};
      width: 2rem;
      height: 2rem;
      display: block;
      left: -1rem;
      top: -1.5rem;
      position: relative;
      border-radius: 2rem 2rem 0;
      transform: rotate(45deg);
      border: 1px solid #FFFFFF;`;
  
    return L.divIcon({
      className: "my-custom-pin",
      iconAnchor: [0, 24],
      popupAnchor: [1, -30],
      html: `<span style="${markerHtmlStyles}" />`
    })
};


interface MapComponentProps {
  center: Location;
  zoom?: number;
  users: UserStatus[];
  tileUrl: string;
  tileAttribution: string;
  currentUserUid: string;
  onMapReady?: (map: L.Map) => void;
}

const MapComponent: React.FC<MapComponentProps> = ({ center, zoom = 16, users, tileUrl, tileAttribution, currentUserUid, onMapReady }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<{ [key: string]: L.Marker }>({});
  const tileLayerRef = useRef<L.TileLayer | null>(null);

  // Initialize map only once
  useEffect(() => {
    if (!mapRef.current && mapContainerRef.current) {
        mapRef.current = L.map(mapContainerRef.current, {
            center: [center.lat, center.lng],
            zoom: zoom,
        });
        tileLayerRef.current = L.tileLayer(tileUrl, { attribution: tileAttribution }).addTo(mapRef.current);
        if (onMapReady) {
            onMapReady(mapRef.current);
        }
    }
    // Cleanup map on component unmount
    return () => {
        mapRef.current?.remove();
        mapRef.current = null;
    };
  }, []); // Should run only once

  // Update map center view without re-initializing
  useEffect(() => {
    if (mapRef.current) {
        mapRef.current.setView([center.lat, center.lng]);
    }
  }, [center]);

  // Update tile layer URL and attribution
  useEffect(() => {
    if (tileLayerRef.current) {
        tileLayerRef.current.setUrl(tileUrl);
        tileLayerRef.current.options.attribution = tileAttribution;
    }
  }, [tileUrl, tileAttribution]);

  // Update user markers
  useEffect(() => {
      if (!mapRef.current) return;
      const map = mapRef.current;
      const onlineUsers = users.filter(u => u.isOnline && u.location);
      const currentMarkerIds = onlineUsers.map(u => u.uid);

      Object.keys(markersRef.current).forEach(markerId => {
          if (!currentMarkerIds.includes(markerId)) {
              markersRef.current[markerId].remove();
              delete markersRef.current[markerId];
          }
      });
      
      onlineUsers.forEach(user => {
        if (user.location) {
          const popupContent = `
            <div class="font-sans">
              <h3 class="font-bold text-lg">${user.name}</h3>
              <p class="text-gray-600">${user.uid === currentUserUid ? 'Your Location' : 'User'}</p>
              <p>Status: <span class="font-semibold capitalize">${user.state}</span></p>
              <p>Lat: ${user.location.lat.toFixed(5)}, Lng: ${user.location.lng.toFixed(5)}</p>
            </div>
          `;
          
          if (markersRef.current[user.uid]) {
            markersRef.current[user.uid].setLatLng([user.location.lat, user.location.lng]);
            markersRef.current[user.uid].getPopup()?.setContent(popupContent);
          } else {
            const marker = L.marker([user.location.lat, user.location.lng], {
              icon: createColoredIcon(user.color || '#3b82f6')
            })
              .addTo(map)
              .bindPopup(popupContent);
            markersRef.current[user.uid] = marker;
          }
        }
      });
  }, [users, currentUserUid]);


  return <div ref={mapContainerRef} className="h-full w-full z-0" />;
};

export default MapComponent;