import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useGeolocation } from '../hooks/useGeolocation';
import { signOutUser, setupPresence, updateUserLocation, updateUserState, listenToAllUsersStatus, listenToMessages } from '../services/firebase';
import { MAP_TILES, MAP_ATTRIBUTION } from '../constants';
import MapComponent from '../components/MapComponent';
import Spinner from '../components/Spinner';
import Notification from '../components/Notification';
import { UserStatus, UserState, Location, AppMessage } from '../types';
import L from 'leaflet';

const UserDashboard: React.FC = () => {
    const { authUser, userData } = useAuth();
    const { location: myLocation } = useGeolocation({ enableHighAccuracy: true, timeout: 5000, maximumAge: 0 });
    
    const [allUsers, setAllUsers] = useState<Record<string, UserStatus>>({});
    const [mapCenter, setMapCenter] = useState<Location>({ lat: 16.7532, lng: -93.1156 });
    const [userState, setUserState] = useState<UserState>(UserState.ACTIVE);
    const [currentTile, setCurrentTile] = useState<keyof typeof MAP_TILES>('VEHICULAR');
    const [notifications, setNotifications] = useState<{ id: number, message: string }[]>([]);
    const [messages, setMessages] = useState<AppMessage[]>([]);
    const mapRef = useRef<L.Map | null>(null);

    const prevUsersRef = useRef<Record<string, UserStatus>>({});

    useEffect(() => {
        if (!userData) return;

        const unsubPresence = setupPresence(userData.uid, userData);
        const unsubStatus = listenToAllUsersStatus((users) => {
            setAllUsers(users || {});
        });
        const unsubMessages = listenToMessages(userData.uid, (msgs) => {
            setMessages(msgs);
        });

        // Cleanup function to unsubscribe from all listeners on component unmount
        return () => {
            unsubPresence();
            unsubStatus();
            unsubMessages();
        };
    }, [userData]);

    useEffect(() => {
        const handleNotifications = () => {
            if (!Object.keys(prevUsersRef.current).length && Object.keys(allUsers).length > 0) {
                prevUsersRef.current = allUsers;
                return;
            }

            const currentOnlineUsers = Object.keys(allUsers).filter(uid => allUsers[uid]?.isOnline);
            const prevOnlineUsers = Object.keys(prevUsersRef.current).filter(uid => prevUsersRef.current[uid]?.isOnline);

            // New user connected
            currentOnlineUsers.forEach(uid => {
                if (!prevOnlineUsers.includes(uid) && uid !== authUser?.uid) {
                    addNotification(`${allUsers[uid].name} se conectó`);
                }
            });

            // User disconnected
            prevOnlineUsers.forEach(uid => {
                const userIsStillOnline = allUsers[uid]?.isOnline;
                if (!userIsStillOnline && uid !== authUser?.uid) {
                     addNotification(`${prevUsersRef.current[uid].name} se desconectó`);
                }
            });

            prevUsersRef.current = allUsers;
        };

        handleNotifications();
    }, [allUsers, authUser?.uid]);

    useEffect(() => {
        if (myLocation && authUser) {
            if (userState === UserState.ACTIVE) {
                updateUserLocation(authUser.uid, myLocation);
            }
            if (mapRef.current?.getCenter().distanceTo([myLocation.lat, myLocation.lng]) > 10) {
                setMapCenter(myLocation);
            }
        }
    }, [myLocation, userState, authUser]);

    const handlePauseToggle = () => {
        if (!authUser) return;
        const newState = userState === UserState.ACTIVE ? UserState.PAUSED : UserState.ACTIVE;
        setUserState(newState);
        updateUserState(authUser.uid, newState);
    };

    const centerMap = () => {
        if (myLocation) {
            mapRef.current?.flyTo([myLocation.lat, myLocation.lng], 16);
        }
    }
    
    const addNotification = (message: string) => {
        setNotifications(prev => [...prev, { id: Date.now(), message }]);
    };

    const removeNotification = (id: number) => {
        setNotifications(prev => prev.filter(n => n.id !== id));
    };

    if (!authUser || !userData) {
        return <div className="h-screen w-screen bg-gray-900 flex items-center justify-center"><Spinner /></div>;
    }

    return (
        <div className="relative h-screen w-screen bg-gray-800 text-white flex flex-col">
            <header className="absolute top-0 left-0 right-0 z-20 flex justify-between items-center p-4 bg-gray-900/50 backdrop-blur-sm">
                <div className="flex items-center gap-4">
                    <h1 className="text-xl font-bold">User Dashboard</h1>
                    <span className={`capitalize px-2 py-1 text-xs rounded-full ${userState === UserState.ACTIVE ? 'bg-green-500' : 'bg-yellow-500'}`}>
                        {userState}
                    </span>
                </div>
                <div className="flex items-center gap-2">
                    <button onClick={centerMap} className="px-3 py-2 bg-blue-600 rounded-md hover:bg-blue-700 transition-colors">Centrar</button>
                    <button onClick={handlePauseToggle} className="px-3 py-2 bg-yellow-500 rounded-md hover:bg-yellow-600 transition-colors">{userState === UserState.ACTIVE ? 'Pausar' : 'Reanudar'}</button>
                    <select onChange={(e) => setCurrentTile(e.target.value as keyof typeof MAP_TILES)} value={currentTile} className="bg-gray-700 border border-gray-600 rounded-md p-2 focus:outline-none">
                        <option value="VEHICULAR">Vehicular</option>
                        <option value="NIGHT">Night</option>
                        <option value="SATELLITE">Satellite</option>
                    </select>
                    <button onClick={signOutUser} className="px-3 py-2 bg-red-600 rounded-md hover:bg-red-700 transition-colors">Logout</button>
                </div>
            </header>
            
            <main className="flex-grow pt-[72px] h-full w-full">
                 <MapComponent 
                    center={mapCenter} 
                    users={Object.values(allUsers)}
                    tileUrl={MAP_TILES[currentTile]}
                    tileAttribution={MAP_ATTRIBUTION[currentTile]}
                    currentUserUid={authUser.uid}
                    onMapReady={(map) => { mapRef.current = map; }}
                 />
            </main>

            {messages.length > 0 && (
                <div className="absolute bottom-5 left-5 z-10 bg-gray-800/80 backdrop-blur-sm p-4 rounded-lg shadow-lg max-w-sm">
                    <h3 className="font-bold mb-2">Admin Messages</h3>
                    <div className="max-h-40 overflow-y-auto pr-2">
                        {messages.slice().reverse().map(msg => (
                            <div key={msg.id} className={`p-2 rounded-md mb-1 ${msg.read ? 'bg-gray-700' : 'bg-blue-900/50'}`}>
                                <p>{msg.text}</p>
                                <p className="text-xs text-gray-400 text-right">{new Date(msg.timestamp).toLocaleTimeString()}</p>
                            </div>
                        ))}
                    </div>
                </div>
            )}
             <div className="fixed top-20 right-5 z-20 space-y-2">
                {notifications.map(n => (
                    <Notification key={n.id} message={n.message} onDismiss={() => removeNotification(n.id)} />
                ))}
            </div>
        </div>
    );
};

export default UserDashboard;