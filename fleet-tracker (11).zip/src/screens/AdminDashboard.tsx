import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../hooks/useAuth';
import { signOutUser, setupPresence, listenToAllUsersStatus, getActivityLogs, sendMessageToUser } from '../services/firebase';
import { MAP_TILES, MAP_ATTRIBUTION, PREDEFINED_MESSAGES } from '../constants';
import MapComponent from '../components/MapComponent';
import Spinner from '../components/Spinner';
import { generatePdfFromElement } from '../utils/pdf';
import { UserStatus, Location, ActivityLog } from '../types';
import { Timestamp } from 'firebase/firestore';

const AdminDashboard: React.FC = () => {
    const { authUser, userData } = useAuth();
    
    const [allUsers, setAllUsers] = useState<Record<string, UserStatus>>({});
    const [selectedUser, setSelectedUser] = useState<UserStatus | null>(null);
    const [selectedUserLogs, setSelectedUserLogs] = useState<ActivityLog[]>([]);
    const [mapCenter, setMapCenter] = useState<Location>({ lat: 16.7532, lng: -93.1156 });
    const [currentTile, setCurrentTile] = useState<keyof typeof MAP_TILES>('NIGHT');
    const [loadingLogs, setLoadingLogs] = useState(false);

    useEffect(() => {
        if (!userData) return;
        
        const unsubPresence = setupPresence(userData.uid, userData);
        const unsubStatus = listenToAllUsersStatus((users) => {
            setAllUsers(users || {});
        });

        // Cleanup function to unsubscribe from all listeners on component unmount
        return () => {
            unsubPresence();
            unsubStatus();
        };
    }, [userData]);

    useEffect(() => {
        // If the selected user's data updates (e.g., location or status), update the state
        if (selectedUser) {
            const updatedSelectedUser = allUsers[selectedUser.uid];
            if (updatedSelectedUser && updatedSelectedUser.isOnline) {
                setSelectedUser(updatedSelectedUser);
            } else {
                setSelectedUser(null);
            }
        }
    }, [allUsers, selectedUser]);


    const handleSelectUser = async (user: UserStatus) => {
        if (selectedUser?.uid === user.uid) { // Center map on already selected user
            if (user.location) setMapCenter(user.location);
            return;
        }
        
        setSelectedUser(user);
        if (user.location) {
            setMapCenter(user.location);
        }
        setLoadingLogs(true);
        setSelectedUserLogs([]);
        try {
            const logs = await getActivityLogs(user.uid);
            setSelectedUserLogs(logs);
        } catch (error) {
            console.error("Error fetching logs:", error);
        } finally {
            setLoadingLogs(false);
        }
    };
    
    const handleSendMessage = (message: string) => {
        if (selectedUser) {
            sendMessageToUser(selectedUser.uid, message);
            alert(`Message sent to ${selectedUser.name}`);
        }
    };

    const handleGenerateReport = () => {
        if (selectedUser) {
            generatePdfFromElement('userDetailPanel', `report-${selectedUser.name.replace(/\s/g, '_')}-${new Date().toISOString().split('T')[0]}.pdf`);
        }
    };
    
    const stats = useMemo(() => {
        if (!selectedUser || selectedUserLogs.length === 0) return { activeTime: '0h 0m', pauses: 0 };
    
        let activeTimeMs = 0;
        let pauses = 0;
        let sessionStart: Timestamp | null = null;
        let pauseStart: Timestamp | null = null;

        const sortedLogs = [...selectedUserLogs].sort((a, b) => a.timestamp.toMillis() - b.timestamp.toMillis());

        for (const log of sortedLogs) {
            const logTime = log.timestamp;
            if (log.event === 'login') {
                if (!sessionStart) sessionStart = logTime;
            } else if (log.event === 'pause_start') {
                pauses++;
                if (sessionStart && !pauseStart) {
                    activeTimeMs += logTime.toMillis() - sessionStart.toMillis();
                }
                pauseStart = logTime;
            } else if (log.event === 'pause_end') {
                if (pauseStart) {
                    sessionStart = logTime; 
                    pauseStart = null;
                }
            } else if (log.event === 'logout') {
                 if (sessionStart && !pauseStart) {
                    activeTimeMs += logTime.toMillis() - sessionStart.toMillis();
                 }
                 sessionStart = null;
                 pauseStart = null;
            }
        }
        
        if (sessionStart && !pauseStart && selectedUser.isOnline) {
            activeTimeMs += Date.now() - sessionStart.toMillis();
        }
        
        const hours = Math.floor(activeTimeMs / 3600000);
        const minutes = Math.floor((activeTimeMs % 3600000) / 60000);

        return { activeTime: `${hours}h ${minutes}m`, pauses };
    }, [selectedUser, selectedUserLogs]);

    const onlineUsers = Object.values(allUsers).filter(u => u.isOnline && u.uid !== userData?.uid);

    if (!authUser || !userData) {
        return <div className="h-screen w-screen bg-gray-900 flex items-center justify-center"><Spinner /></div>;
    }

    return (
        <div className="h-screen w-screen bg-gray-900 text-white flex">
            <aside className="w-1/3 max-w-sm flex flex-col h-full bg-gray-800 p-4 border-r border-gray-700">
                <div className="flex justify-between items-center mb-4 flex-shrink-0">
                    <h1 className="text-xl font-bold">Admin Panel</h1>
                    <button onClick={signOutUser} className="px-3 py-1 bg-red-600 rounded-md hover:bg-red-700 text-sm transition-colors">Logout</button>
                </div>

                <div className="flex-shrink-0 mb-4">
                    <h2 className="text-lg font-semibold mb-2">Connected Users ({onlineUsers.length})</h2>
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                        {onlineUsers.map(user => (
                            <button key={user.uid} onClick={() => handleSelectUser(user)}
                                className={`w-full flex items-center p-2 rounded-md cursor-pointer transition-colors text-left ${selectedUser?.uid === user.uid ? 'bg-blue-600' : 'bg-gray-700 hover:bg-gray-600'}`}>
                                <span className="w-3 h-3 rounded-full mr-3 flex-shrink-0" style={{ backgroundColor: user.color }}></span>
                                <span className="flex-grow truncate">{user.name}</span>
                                <span className={`capitalize text-xs px-2 py-0.5 rounded-full ${user.state === 'active' ? 'bg-green-500/50' : 'bg-yellow-500/50'}`}>{user.state}</span>
                            </button>
                        ))}
                    </div>
                </div>

                <div className="flex-grow bg-gray-900 rounded-lg p-1 overflow-y-auto flex flex-col">
                  <div id="userDetailPanel" className="p-3 flex-grow">
                    <h2 className="text-lg font-semibold mb-2">User Details</h2>
                    {selectedUser ? (
                        <div className="space-y-3">
                            <h3 className="text-xl font-bold text-blue-400">{selectedUser.name}</h3>
                            <p><span className="font-semibold">Status:</span> <span className="capitalize">{selectedUser.state}</span></p>
                            <p><span className="font-semibold">Active Time (24h):</span> {stats.activeTime}</p>
                            <p><span className="font-semibold">Pauses (24h):</span> {stats.pauses}</p>
                            
                            <div className="space-y-2 pt-2">
                               <h4 className="font-semibold">Send Message:</h4>
                               <div className="flex flex-col gap-2">
                                   {PREDEFINED_MESSAGES.map(msg => (
                                       <button key={msg} onClick={() => handleSendMessage(msg)} className="text-left text-sm w-full p-2 bg-gray-700 hover:bg-gray-600 rounded-md transition-colors">{msg}</button>
                                   ))}
                               </div>
                            </div>

                             <div className="space-y-2 pt-2">
                               <h4 className="font-semibold">Activity Log (Last 24h):</h4>
                               {loadingLogs ? <div className="flex justify-center p-4"><Spinner /></div> : (
                                   <div className="text-xs space-y-1 max-h-40 overflow-y-auto pr-2">
                                       {selectedUserLogs.map(log => (
                                           <div key={log.id} className="flex justify-between p-1 bg-gray-800 rounded">
                                               <span className="capitalize">{log.event.replace(/_/g, ' ')}</span>
                                               <span className="text-gray-400">{log.timestamp.toDate().toLocaleString()}</span>
                                           </div>
                                       ))}
                                        {selectedUserLogs.length === 0 && <p className="text-gray-500">No activity in last 24h.</p>}
                                   </div>
                               )}
                            </div>
                        </div>
                    ) : <p className="text-gray-400">Select a user to see details.</p>}
                   </div>
                   {selectedUser && <button onClick={handleGenerateReport} className="m-3 mt-auto w-[calc(100%-1.5rem)] py-2 bg-green-600 hover:bg-green-700 rounded-md transition-colors flex-shrink-0">Generate PDF Report</button>}
                </div>
            </aside>
            <main className="flex-grow relative">
                 <MapComponent 
                    center={mapCenter} 
                    users={Object.values(allUsers)}
                    tileUrl={MAP_TILES[currentTile]}
                    tileAttribution={MAP_ATTRIBUTION[currentTile]}
                    currentUserUid={authUser.uid}
                 />
                 <div className="absolute top-4 right-4 z-10">
                     <select onChange={(e) => setCurrentTile(e.target.value as keyof typeof MAP_TILES)} value={currentTile} className="bg-gray-700 border border-gray-600 rounded-md p-2 focus:outline-none">
                        <option value="VEHICULAR">Vehicular</option>
                        <option value="NIGHT">Night</option>
                        <option value="SATELLITE">Satellite</option>
                    </select>
                 </div>
            </main>
        </div>
    );
};

export default AdminDashboard;