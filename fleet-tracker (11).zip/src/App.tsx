import React from 'react';
import { useAuth } from './hooks/useAuth';
import Login from './components/Login';
import AdminDashboard from './screens/AdminDashboard';
import UserDashboard from './screens/UserDashboard';
import LoadingScreen from './screens/LoadingScreen';
import { Role } from './types';

const App: React.FC = () => {
  const { authUser, userData, loading } = useAuth();

  if (loading) {
    return <LoadingScreen />;
  }

  if (!authUser || !userData) {
    return <Login />;
  }

  if (userData.role === Role.ADMIN) {
    return <AdminDashboard />;
  }
  
  if (userData.role === Role.USER) {
    return <UserDashboard />;
  }
  
  // Fallback in case of unexpected role or data mismatch
  console.warn(`User ${userData.email} has an unknown role ('${userData.role}') or data is missing, showing login screen.`);
  return <Login />;
};

export default App;