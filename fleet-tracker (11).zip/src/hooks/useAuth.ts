
import { useState, useEffect } from 'react';
import { auth, onAuthStateChanged, getUserData, FirebaseUser } from '../services/firebase';
import { UserData } from '../types';

export const useAuth = () => {
  const [authUser, setAuthUser] = useState<FirebaseUser | null>(null);
  const [userData, setUserData] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const data = await getUserData(user.uid);
        setAuthUser(user);
        setUserData(data);
      } else {
        setAuthUser(null);
        setUserData(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return { authUser, userData, loading };
};
